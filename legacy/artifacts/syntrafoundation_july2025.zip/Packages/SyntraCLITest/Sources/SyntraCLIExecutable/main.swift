// SYNTRA CLI Executable Entry Point
// Minimal main.swift that calls the library functionality

import SyntraCLILib

// Entry point - call the library's run function
await SyntraCLI.run() 