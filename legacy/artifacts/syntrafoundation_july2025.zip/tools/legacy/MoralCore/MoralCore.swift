import Foundation; public struct MoralCore { public init() {} }
