import Foundation; public struct SyntraConfig { public init() {} }
