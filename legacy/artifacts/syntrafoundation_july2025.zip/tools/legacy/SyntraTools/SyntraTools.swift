import Foundation; public struct SyntraTools { public init() {} }
