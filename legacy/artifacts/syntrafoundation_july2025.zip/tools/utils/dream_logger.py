def log_dream(event):
    print(f"[DREAM] {event}")
