"""Legacy helper utilities for SYNTRA."""

from utils.io_tools import load_config

__all__ = ["load_config"]
