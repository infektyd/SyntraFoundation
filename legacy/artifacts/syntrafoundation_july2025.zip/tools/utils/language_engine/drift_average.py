"""
Stub so ingest.pdf_ingestor can import drift_average from utils.language_engine
"""
def drift_average(*args, **kwargs):
    return None
