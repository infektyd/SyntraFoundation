🚀🚀🚀 [SyntraApp] ===== APP STRUCT INIT CALLED =====
📱 [SyntraApp] iOS Version: 26.0
📱 [SyntraApp] Device Model: iPhone
📱 [SyntraApp] Device Name: iPhone
🏗️ [SyntraApp] Build Configuration: 1
📦 [SyntraApp] Bundle ID: com.HansAxelsson.syntra
✅ [SyntraApp] App struct init() completed
🎨 [SyntraApp] Generating app icon...
🎨 SYNTRA Celtic Knot App Icon Generator
==================================================
🚀🚀🚀 [SyntraAppDelegate] ===== DID FINISH LAUNCHING =====
🔒 [SyntraApp] SAFETY: App launched with keyboard crash prevention enabled
📋 [SyntraApp] Launch options: nil
🛡️ [SyntraApp] SIGPIPE protection enabled
✅ [SyntraAppDelegate] didFinishLaunching returning TRUE
🪟🪟🪟 [SyntraApp] ===== CREATING WINDOWGROUP =====
🎯 [SyntraApp] About to create WindowGroup with ContentView
🎯🎯🎯 [ContentView] ===== CONTENTVIEW INIT CALLED =====
📱📱📱 [ContentView] ===== CREATING TABVIEW BODY =====
✅ [ContentView] Full TabView interface loaded
✨✨✨ [SyntraApp] ===== CONTENTVIEW APPEARED! UI IS WORKING! =====
🎉 [SyntraApp] WindowGroup successfully rendered!
[2025-07-27T01:03:47Z] [INFO] [General] [SyntraCore] Loaded 32 conversation memory items
[SyntraCore] Loaded 32 conversation memory items
[FileLogger] Log file ready at: /var/mobile/Containers/Data/Application/5768D048-245E-4097-BE22-AD33159A8E8B/Documents/syntra_consciousness_logs.txt
[2025-07-27T01:03:47Z] [INFO] [General] [SyntraCore] Loaded persistent memory with 4 keys
[SyntraCore] Loaded persistent memory with 4 keys
[2025-07-27T01:03:47Z] [INFO] [FoundationModels] Initializing Apple Foundation Models for on-device processing...
Initializing Apple Foundation Models for on-device processing...
❌ Failed to save icon: Error Domain=NSCocoaErrorDomain Code=4 "The file “AppIcon-1024.png” doesn’t exist." UserInfo={NSFilePath=/Users/hansaxelsson/Library/CloudStorage/Dropbox/SyntraFoundation/Apps/iOS/SyntraChatIOS/SyntraChatIOS/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png, NSURL=file:///Users/hansaxelsson/Library/CloudStorage/Dropbox/SyntraFoundation/Apps/iOS/SyntraChatIOS/SyntraChatIOS/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png, NSUnderlyingError=0x132d52010 {Error Domain=NSPOSIXErrorDomain Code=2 "No such file or directory"}}
✅ Generated 1024x1024 app icon
[2025-07-27T01:03:47Z] [INFO] [FoundationModels] Foundation Models successfully initialized as core LLM engine
Foundation Models successfully initialized as core LLM engine
[2025-07-27T01:03:47Z] [INFO] [FoundationModels] Model availability status
Model availability status
[2025-07-27T01:03:47Z] [INFO] [General] [SyntraCore] Offline-first architecture initialized
[SyntraCore] Offline-first architecture initialized
🗣️ [ChatView] Creating ChatView...
❌ Failed to update Contents.json: Error Domain=NSCocoaErrorDomain Code=4 "The folder “Contents.json” doesn’t exist." UserInfo={NSUserStringVariant=Folder, NSURL=file:///Users/hansaxelsson/Library/CloudStorage/Dropbox/SyntraFoundation/Apps/iOS/SyntraChatIOS/SyntraChatIOS/Assets.xcassets/AppIcon.appiconset/Contents.json, NSUnderlyingError=0x133023b10 {Error Domain=NSPOSIXErrorDomain Code=2 "No such file or directory"}}
✅ App icon generation complete!
📱 Your SYNTRA app now has a beautiful Celtic knot icon!
[2025-07-27T01:03:47Z] [INFO] [UI] SYNTRA Chat interface initialized
SYNTRA Chat interface initialized
[2025-07-27T01:03:47Z] [INFO] [Consciousness] Three-brain architecture ready (Valon 70%, Modi 30%)
Three-brain architecture ready (Valon 70%, Modi 30%)
[2025-07-27T01:03:47Z] [INFO] [FoundationModels] On-device AI processing capabilities verified
On-device AI processing capabilities verified
[2025-07-27T01:03:47Z] [INFO] [Memory] Conversation memory system active
Conversation memory system active
[2025-07-27T01:03:47Z] [INFO] [Network] Offline-first architecture enabled
Offline-first architecture enabled
✅ [Tab] ChatView tab loaded
🔧🔧🔧 [SyntraApp] SETTING UP iOS APPEARANCE...
[2025-07-27T01:03:47Z] [INFO] [Memory] Memory systems initialized
Memory systems initialized
[2025-07-27T01:03:47Z] [INFO] [General] [SyntraCore] Network status: connected
[SyntraCore] Network status: connected
SyntraThreadSafeTextInput initialized with consciousness integration: true
[2025-07-27T01:03:47Z] [INFO] [Consciousness] [SyntraBrain iOS] Starting consciousness processing
[SyntraBrain iOS] Starting consciousness processing
[2025-07-27T01:03:47Z] [INFO] [UI] SYNTRA brain state transition: idle → processing
SYNTRA brain state transition: idle → processing
[2025-07-27T01:03:47Z] [INFO] [Memory] Loading conversation context
Loading conversation context
[2025-07-27T01:03:47Z] [INFO] [Consciousness] Context prepared for three-brain processing
Context prepared for three-brain processing
[2025-07-27T01:03:47Z] [INFO] [Consciousness] Engaging Valon (70%) + Modi (30%) synthesis...
Engaging Valon (70%) + Modi (30%) synthesis...
[2025-07-27T01:03:47Z] [INFO] [General] [SyntraCore] Starting agentic processing for: 'Hello' with context session: ABBF4B5D-4379-43CB-BB66-C47FEC24B823
[SyntraCore] Starting agentic processing for: 'Hello' with context session: ABBF4B5D-4379-43CB-BB66-C47FEC24B823
[2025-07-27T01:03:47Z] [INFO] [General] [SyntraCore] Integrating with persistent memory for input: 'Hello'
[SyntraCore] Integrating with persistent memory for input: 'Hello'
[2025-07-27T01:03:47Z] [INFO] [Consciousness] Starting consciousness processing with Foundation Models
Starting consciousness processing with Foundation Models
[2025-07-27T01:03:47Z] [INFO] [FoundationModels] Sending prompt to Foundation Models
Sending prompt to Foundation Models
📲 [SyntraApp] App became active
[SyntraApp] CRASH PREVENTION: Cursor indicators disabled for Beta 3 compatibility
🗣️ [ChatView] Creating ChatView...
[2025-07-27T01:03:49Z] [INFO] [FoundationModels] Foundation Models response received
Foundation Models response received
[2025-07-27T01:03:49Z] [INFO] [Consciousness] Consciousness processing complete
Consciousness processing complete
[2025-07-27T01:03:49Z] [INFO] [Memory] Stored in dual-stream memory
Stored in dual-stream memory
[2025-07-27T01:03:49Z] [INFO] [Memory] Stored in modern memory vault
Stored in modern memory vault
[2025-07-27T01:03:49Z] [INFO] [Memory] Memory systems updated successfully
Memory systems updated successfully
[2025-07-27T01:03:49Z] [INFO] [General] [SyntraCore] Storing in persistent memory: input='Hello', response='Hello! I'm glad to connect with you. How can I assist you today, keeping in mind the richness of context and your preferences?'
[SyntraCore] Storing in persistent memory: input='Hello', response='Hello! I'm glad to connect with you. How can I assist you today, keeping in mind the richness of context and your preferences?'
[2025-07-27T01:03:49Z] [INFO] [General] [SyntraCore] Agentic processing complete
[SyntraCore] Agentic processing complete
[2025-07-27T01:03:49Z] [INFO] [Consciousness] Three-brain synthesis complete
Three-brain synthesis complete
[2025-07-27T01:03:49Z] [INFO] [Memory] Storing interaction in conversation memory
Storing interaction in conversation memory
[2025-07-27T01:03:49Z] [INFO] [Memory] Memory consolidation triggered
Memory consolidation triggered
[2025-07-27T01:03:49Z] [INFO] [Memory] Memory stored in UserDefaults
Memory stored in UserDefaults
[2025-07-27T01:03:49Z] [INFO] [Memory] Memory backed up to file system
Memory backed up to file system
[2025-07-27T01:03:49Z] [INFO] [Memory] Memory stored successfully
Memory stored successfully
[2025-07-27T01:03:49Z] [INFO] [UI] SYNTRA brain state transition: processing → ready
SYNTRA brain state transition: processing → ready
[2025-07-27T01:03:49Z] [INFO] [Consciousness] [SyntraBrain iOS] Consciousness cycle complete
[SyntraBrain iOS] Consciousness cycle complete
🗣️ [ChatView] Creating ChatView...
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
containerToPush is nil, will not push anything to candidate receiver for request token: C44897EF
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
[SyntraApp] SECURITY: Blocking custom keyboard to prevent Beta 3 crashes
*** Assertion failure in void PushNextClassForSettingIMP(id, SEL)(), UIAppearance.m:760
*** Terminating app due to uncaught exception 'NSInternalInconsistencyException', reason: 'Have you sent -setKeyboardAppearance: to <UITextView: 0x132321800; frame = (0 0; 0 0); text = ''; hidden = YES; userInteractionEnabled = NO; gestureRecognizers = <NSArray: 0x133506e50>; backgroundColor = UIExtendedGrayColorSpace 0 0; layer = <CALayer: 0x133506b50>; contentOffset: {0, 0}; contentSize: {0, 0}; adjustedContentInset: {0, 0, 0, 0}> off the main thread? To verify, look for a complaint in the logs: "Unsupported use of UIKit…", and fix the problem if you find it. If your use is main-thread only please file a radar on UIKit, and attach this log. exercisedImplementations = {
    "setKeyboardAppearance:" =     (
    );
}'
*** First throw call stack:
(0x18a47d9a8 0x1876057a4 0x1896e3600 0x18d213d64 0x18d2b0380 0x18e96a00c 0x18d2afd40 0x18df5bbe4 0x18e988144 0x18e9880b0 0x18e916fbc 0x18e987be0 0x18e987450 0x18e919f5c 0x18e7c53a4 0x18e987224 0x18e919f5c 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e97e610 0x1b14acd64 0x18e97e538 0x18e98976c 0x18e1c50bc 0x18e1c3ab4 0x18e1bf050 0x18e1bf784 0x18e1c0b5c 0x18e1b7694 0x18e1c0840 0x18e1b5648 0x18de0a5e0 0x18de09b20 0x18de0abd8 0x18de0ac3c 0x18de08084 0x18e2177ec 0x102ec62b0 0x102eb00b8 0x102ec615c 0x102ec4ca4 0x102ee7370 0x102ebc758 0x102ebc694 0x18a41f600 0x18a3d1df4 0x18a3d0d24 0x1dbea8498 0x18d158428 0x18d0f70b8 0x18f44f464 0x18f44bfc0 0x18f44baac 0x103530528 0x1035305d4 0x187659b18)
libc++abi: terminating due to uncaught exception of type NSException
*** Terminating app due to uncaught exception 'NSInternalInconsistencyException', reason: 'Have you sent -setKeyboardAppearance: to <UITextView: 0x132321800; frame = (0 0; 0 0); text = ''; hidden = YES; userInteractionEnabled = NO; gestureRecognizers = <NSArray: 0x133506e50>; backgroundColor = UIExtendedGrayColorSpace 0 0; layer = <CALayer: 0x133506b50>; contentOffset: {0, 0}; contentSize: {0, 0}; adjustedContentInset: {0, 0, 0, 0}> off the main thread? To verify, look for a complaint in the logs: "Unsupported use of UIKit…", and fix the problem if you find it. If your use is main-thread only please file a radar on UIKit, and attach this log. exercisedImplementations = {
    "setKeyboardAppearance:" =     (
    );
}'
*** First throw call stack:
(0x18a47d9a8 0x1876057a4 0x1896e3600 0x18d213d64 0x18d2b0380 0x18e96a00c 0x18d2afd40 0x18df5bbe4 0x18e988144 0x18e9880b0 0x18e916fbc 0x18e987be0 0x18e987450 0x18e919f5c 0x18e7c53a4 0x18e987224 0x18e919f5c 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e987224 0x18e97e610 0x1b14acd64 0x18e97e538 0x18e98976c 0x18e1c50bc 0x18e1c3ab4 0x18e1bf050 0x18e1bf784 0x18e1c0b5c 0x18e1b7694 0x18e1c0840 0x18e1b5648 0x18de0a5e0 0x18de09b20 0x18de0abd8 0x18de0ac3c 0x18de08084 0x18e2177ec 0x102ec62b0 0x102eb00b8 0x102ec615c 0x102ec4ca4 0x102ee7370 0x102ebc758 0x102ebc694 0x18a41f600 0x18a3d1df4 0x18a3d0d24 0x1dbea8498 0x18d158428 0x18d0f70b8 0x18f44f464 0x18f44bfc0 0x18f44baac 0x103530528 0x1035305d4 0x187659b18)
terminating due to uncaught exception of type NSException
Message from debugger: killed
